-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: resident2
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `codigo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Tanya','doctorejemplo@gmail.com','$2b$12$6TBjtRFGyY7hJBLoHIzSnebDYN2Ok/.PKzFF1DHLIpdh1u/e7TTDy','2025-03-29 23:04:13','CC2024'),(2,'Felipe','pacienteejemplo@gmail.com','$2b$12$yJYqED0q6b.HwbVXhyYDEexR6Vb9WHG.6FPgtv2CAvtGgQS.VgFBG','2025-03-29 23:40:34','CC2025'),(4,'Maria','paciente2@gmail.com','$2b$12$TDWhdNRF8e5Kgb3Hq0Nrhuh7N6vuz0f.JSL7N1aKaR3d09ufq5C4e','2025-03-30 00:18:36','CC2025'),(5,'Tanya','admin@gmail.com','$2b$12$XrTTyMH8NkSmrwgS6dmGHeOyXexNnGv6vAEBlgsnzKymQ/hl87dAO','2025-05-12 03:46:04','Admincode'),(6,'Raul','Rdoctor@gmail.com','$2b$12$yKO71qfIyyiJ1AmWIl5k8.127EoM4czqNHcvbjbxcWeXk4SpbsnsS','2025-05-15 23:37:37','CC2024'),(7,'Tanya','doctor2@gmail.com','$2b$12$o26dfz/jpGficujm3biLXuNviyaDy.LYCHIbdlQlGYKMkHzAJFRzq','2025-05-16 00:36:23','CC2024'),(10,'Rosa','pacienteejemplo1@gmail.com','$2b$12$RTRGVE/JRJPT8O5or5axFObv.CWn.LtVAeG6Oa3nKQm.9s/8ipMvS','2025-05-19 01:54:42','CC2025'),(11,'Laura','doctor@gmail.com','$2b$12$bX9Qvxaara25u00azPtF6u322nma830iJwUdvn/Eu9rPk74TkYlBy','2025-05-19 03:45:36','CC2024');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-10 16:56:40
