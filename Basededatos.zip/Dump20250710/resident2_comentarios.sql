-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: resident2
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comentarios`
--

DROP TABLE IF EXISTS `comentarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comentarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_archivo` int NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `comentario` text NOT NULL,
  `fecha` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `tipo_perfil` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_archivo` (`id_archivo`),
  CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`id_archivo`) REFERENCES `archivos_paciente` (`id`),
  CONSTRAINT `chk_tipo_perfil` CHECK ((`tipo_perfil` in (_utf8mb4'perfil',_utf8mb4'paciente')))
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comentarios`
--

LOCK TABLES `comentarios` WRITE;
/*!40000 ALTER TABLE `comentarios` DISABLE KEYS */;
INSERT INTO `comentarios` VALUES (1,1,'Tanya','El pico QRS de la señal del ECG es...','2025-03-29 23:31:40','perfil'),(2,1,'Tanya','El fonocardiograma demuestra que es un...','2025-03-30 00:12:02','paciente'),(3,1,'Tanya','Además de que...','2025-03-30 00:12:25','paciente'),(4,1,'Paola','El sonido me permite decir que...','2025-03-30 00:15:01','paciente'),(5,5,'Tanya','asa','2025-05-09 19:29:26','perfil'),(6,1,'Tanya','asasd','2025-05-09 19:30:41','paciente'),(7,9,'Raul','La señal de ECG se ve...','2025-05-15 23:50:06','perfil'),(8,10,'Tanya','hola','2025-05-16 00:37:52','perfil'),(9,12,'Tanya','la señal de ECG muestra...','2025-05-19 01:43:08','perfil'),(10,2,'Tanya','El fonocardiograma se ve sano','2025-05-19 02:04:31','paciente'),(11,4,'Tanya','hola','2025-06-02 02:22:34','paciente');
/*!40000 ALTER TABLE `comentarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-10 16:56:39
